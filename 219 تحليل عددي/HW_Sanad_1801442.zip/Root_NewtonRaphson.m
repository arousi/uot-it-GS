function[] = Root_NewtonRaphson()

    fprintf("================================================================\nEntered Root Newton Raphson function\n");
    fprintf("================================================================\n");

x = input("Starting guess: ");
Error_Toleranceerance = 1e-8;
iterations = 0;

while (iterations<30) && (abs(func(x))>Error_Toleranceerance)
    x = x-func(x)/func_prime(x);
    iterations = iterations + 1;
end

if iterations==30
    fprintf("\nNo root found\n");
else
    disp([" Root = " num2str(x,10) " found in " ...
    int2str(iterations) " iterations."]);
end

fprintf("================================================================\nExit Root Newton Raphson function\n");
fprintf("================================================================\n");

end
