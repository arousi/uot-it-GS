function [value] = Lagrange()

global x f

fprintf("\nRemember to change the input"); %M = N/2;unsued even in sheet
[itop , ibot] = find_range();
ip = ibot : itop;
il = 1:N;
f_z = 0.0;

for ii = 1:N
    k=find(il~=ii);
    prod = f(ip(ii));
    for j = k
        prod = prod * z-x(ip(j)) / (x(ip(ii)))-x(ip(j));
    end

    f_z = f_z + prod;
end
value = f_z;
end