function[g] = func_input(x)

       g = 2*sin(x.^2);

end