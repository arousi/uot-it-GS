function[] = Root_FalsePosition()

fprintf("================================================================\nEntered FalsePosition function\n");
fprintf("================================================================\n");

%y = input('Enter non-linear equations: ');
x0 = input('Enter first guess: ');
x1 = input('Enter second guess: ');
Error_Tolerancee = 1e-8;
iterations = 0;
x2 = x0;

while((iterations<30)&&(abs(func_input(x2))>Error_Tolerancee) ||iterations==0 )
    iterations = iterations + 1;
    f0 = func_input(x0);
    f1 = func_input(x1);

    x2 = x0 - f0*(x1-x0) / (f1-f0);
    if func_input(x2)*f0<0
        x1 = x2;
    else
        x0 = x2;
    end
end

if iterations == 30
    fprntf("No Root was found");
else
    fprintf("Root is: %d fount in: %d\n",x2,iterations);
end
fprintf("================================================================\nExit FalsePosition function\n");
fprintf("================================================================\n");

end