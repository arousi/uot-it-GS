function[itop,ibot] = find_range_and_Lagrange(x1)
x = x1;
fprintf("================================================================\nEntered find_range_and_Lagrange() function\n");
fprintf("================================================================\n");

%x = input("\nThis is a function for Lagrange and Newton Forw-Back\n Input 1 for Newton Forw-Back\nInput 2 for Lagrange:\n");
exit = 1;
global ibot  itop f x2
z = input("Input Z");
N = input("Input N");
x_vector = [1,2,3,4,5,6,7,8];
imax = length(x_vector);

if x1 == 1 %Newton Forward-Backward
    fprintf("\n=====================\nNewton Forw-Backw\n=====================\n");
    while exit ==1
        if mod(N+1 , 2) ~= 0
            fprintf("\nMust use an odd number for N\nResetting\n");
            continue;
        elseif N >= imax
            fprintf("\nToo many points used, repeat:\n");
            continue;
        else
            points = (N+1)/2;
            [ii] = find(x_vector>z);
        
            if isempty(ii)
                i = length(x_vector);
            else
                i = ii(1);
        
            end
        
            itop = i+points-1;
            ibot = i-points;
            fprintf("\nBefore:\n=======================\nTop is: %d, Bot is: %d\n=======================\n",ibot,itop);
            if itop > length(x_vector)
                itop = length(x_vector);
                ibot = length(x_vector) - 2*points + 1;
                fprintf("\nTop is: %d, Bot is: %d\n",itop,ibot);
            elseif ibot<1
                itop = 2*points;
                ibot = 1;
                fprintf("\nTop is: %d, Bot is: %d\n",itop,ibot);
            end
            exit = input("\nDo you want to exit find_range? input 0 for Exit, input 1 to run again");
        end
    %is the itob and ibot equations switched in the sheet?
    end
elseif x1 == 2 %Lagrange
    
    fprintf("\n=====================\nLagrange\n=====================\n");
    ip = ibot : itop;
    il = 1:N;
    f_z = 0.0;
    
    for ii = 1:N
        k=find(il~=ii);
        prod = f(ip(ii));
        for j = k
            prod = prod * z-x2(ip(j)) / (x2(ip(ii)))-x2(ip(j));
            fprintf("\nprod is: %d\n",prod);
        end
        f_z = f_z + prod;
        fprintf("\n=================\nf_z is: %d\n",f_z);
    end
    value = f_z;
    fprintf("\n=====================\nValue is: %d\n",value);
end

fprintf("================================================================\nExited find range 'Newton Forw-Backw' function\n");
fprintf("================================================================\n");

end