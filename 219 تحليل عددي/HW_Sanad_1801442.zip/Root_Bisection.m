% Bisection Method
function[] = Root_Bisection()
%a lower limit
%b upper limit
fprintf("================================================================\nEntered Bisection function\n");
fprintf("================================================================\n");
%func_input= str2fc(input("Enter Your funciton: ","s"));

MaxIter = input("Input Max number of Iterations:");
iterations = 0;
iflag = 0;
Error_Tolerance = 1e-4;

a = input("Input lower limit");
b = input("Input upper limit");


%f = x-2*sin(x); %issues here
f_a = func1Bisection(a);
f_b = func1Bisection(b);


while (((f_a*f_b<0) && iterations < MaxIter) && ((b-a)>Error_Tolerance))
    iterations = iterations+1;
    c=(b+a)/2;
    f_c=func1Bisection(c);

    if f_c*f_a < 0
        b=c; f_b = f_c;
    elseif f_b*f_c < 0
        a=c;
        f_a = f_c;
    else
        iflag = 1;
        answer = c;
    end
end
 switch iterations
     case MaxIter
         iflag = -1; 
         answer = NaN;
     case 0
         iflag = -2; 
         answer = NaN;
     otherwise
         iflag = iterations;
         answer = c;
 end

 switch iflag
  case -1
        fprintf("\nRoot finding failed\n");
  case -2
        fprintf("\nInitial range doesn't contain only 1 root\n");
  otherwise
        fprintf("\nRoot is: %d found in %d iterations\n",answer,iflag);
  end

fprintf("================================================================\nExit Bisection function\n");
fprintf("================================================================\n");
end