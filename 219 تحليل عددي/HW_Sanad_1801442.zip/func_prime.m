%function prime
function[value] = func_prime(x)

    value = 1 - 4*x.*cos(x.^2);

end