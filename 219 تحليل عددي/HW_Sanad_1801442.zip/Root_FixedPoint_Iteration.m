function[] = Root_FixedPoint_Iteration()
    
    fprintf("================================================================\nEntered Fixed Point Function\nFunction is in file to be edited on need\n");
    fprintf("================================================================\n");

    %func_input= str2func(input("Enter Your Funciton: ","s"));
    %f = sym(func_input);
    %diff(f,x);

    fprintf("================================================================\nEntered Fixed Point Iteration function\n");
    fprintf("================================================================\n");
    iter = 0;
    iflag = 0;
    ErrorToler = 1e-4;

    x0= input("Enter First Iter: x0");
    MaxIter= input("Input max Number of Iterations");
    
    %func_input = 2*sin(x.^2);%issues here
    xnext = func_input(x0);
    
    
    while (iter < MaxIter) && abs(xnext-x0) > ErrorToler
        iter=iter+1;
        x0 = xnext;
        xnext = func_input(x0);
        fprintf("x%d = %.4f\n",iter,xnext);
    end

    if (iter == MaxIter)
        iflag = -1;
        answer = NaN;
    else
        iflag = iter;
        answer = xnext;
    end

    switch iflag
       case -1
          disp("Failed root finding check inputs and funciton");
        otherwise
          fprintf("Root is: %d, Found in: %d iterations\n",answer,iter);
    end

    fprintf("================================================================\nExit Fixed Point Function\n");
    fprintf("================================================================\n");

end
