function[] = plotting()
    
    x = -2.0 : 0.01 : 2.0;
    par1 = input("Input par1: ");
    par2 = input("Input par2: ");
    
    value = x-par1.*sin(x.^par2);

    y = feval("userfn", x,2,2);

    fprintf("Click the mouse near the Zero\nWehn finished press RETURN key.\n");

    plot(x,y);
    grid on;
    [xvalue,yvalue] = ginput
    [yy,ii] = min(abs(yvalue));
    dsip(xvalue(ii));

end