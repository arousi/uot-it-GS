function[f] = func1Bisection(x)

    f = x-2*sin(x.^2); %or change it based on input

end