exit=0;

global Error_Tolerance MaxIter
Error_Tolerance = 1e-4;
MaxIter = 30;


fprintf("\nSanad HW 2181801442\nPlease select the wanted method:\n");
while exit == 0
    ExtrapInterp_OR_Root = input("\nInput 1 for Root finding methods, input 2 for Extrapolation_Interpolation methods: ");
    try
        if ExtrapInterp_OR_Root==1
            Root_Finding = input("Select a method for Root Finding:\n1)Drawing\n2)Fixed Point Iteration\n3)Bisection\n4)Newton Raphson\n5)False Poision\n\n");
            if Root_Finding==1 %drawing
                plotting();
    
            elseif Root_Finding==2 %Fixed Point Iterations
                Root_FixedPoint_Iteration();
    
            elseif Root_Finding==3 %bisection
                Root_Bisection();
                
            elseif Root_Finding==4 %newton
                Root_NewtonRaphson();
    
            elseif Root_Finding==5 %false
                Root_FalsePosition();
                
            else
                fprintf("\nWrong Input\nResetting\n=======================================\n");
                continue;
            end
    
        elseif ExtrapInterp_OR_Root==2
            Extrap_Interp = input("Select a method for Interpolation and extrapolation:\n1)Newton Forward\n2)Newton Backwards\n3)Lagrange Method\n4)Splines\n\n");
            %Might not work at all
                if Extrap_Interp==1 || Extrap_Interp==2
                    find_range_and_Lagrange(1); %Newton Forward input 1
                elseif Extrap_Interp==3
                    find_range_and_Lagrange(2); %Lagrane input 2
                elseif Extrap_Interp==4 %Spline
                    x = [1 2 3 5];
                    f = [4 2 0 3];
                    z = 0 : 0.1 : 5;
                    y = spline(x,f,z); 
                    plot(z,y,x,f,'o', 'MarkerSize' , 12)
                else
                    fprintf("Wrong Input\nResetting\n=======================================\n\n");
                    continue;
                end
        else
            fprintf("Wrong Input\nResetting\n=======================================\n\n");
            continue;
        end
    
    
        exit = input("\n\n=======================================\nDo you want to exit main?\n Yes: input 1, No input 0");
        if exit == 1
            return
        else
            fprintf("Wrong Input\nResettin\n=======================================\n\n");
            continue;
        end
    catch ME
        fprintf("\n=========================================\n");
        fprintf("||============ Error occured =========||");
        fprintf("\n=========================================\n");
    end
end